from .src.dog import Dog
from .src.cat import Cat
from .src import laboratory